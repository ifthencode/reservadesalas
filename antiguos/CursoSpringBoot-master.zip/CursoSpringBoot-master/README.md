# **Curso Arquitectura de Aplicaciones basadas en Spring Boot**
Este curso está preparado para aprender a montar una aplicación con Spring Boot. Las tecnologías utilizadas son:

- Spring Boot
- Spring Security
- JPA
- Bootstrap + Thymleaf
- MariaDB (MySQL en su defecto)
- Maven

Presentación:
https://docs.google.com/presentation/d/1sNxAiEuFFwBEUpQ8ujwrUDKbLicFSNlJVNMBJXsqcqA/edit?usp=sharing
