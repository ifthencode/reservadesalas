package com.curso.alumnos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlumnosApplication {

	public static void main(String[] args) {
		//inicio test
		SpringApplication.run(AlumnosApplication.class, args);
		//fin test proba ndo
	}
}
