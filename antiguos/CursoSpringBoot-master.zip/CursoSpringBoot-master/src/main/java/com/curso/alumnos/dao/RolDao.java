package com.curso.alumnos.dao;

import java.util.List;

import com.curso.alumnos.dto.RolDto;



public interface RolDao{
	
	List<RolDto> getRoles();
}
