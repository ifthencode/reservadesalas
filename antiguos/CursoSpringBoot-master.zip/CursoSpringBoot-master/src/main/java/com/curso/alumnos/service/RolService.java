package com.curso.alumnos.service;

import java.util.List;

import com.curso.alumnos.dto.RolDto;

public interface RolService {

	List<RolDto> getRoles();
}
